//
//  ForgotController.swift
//  priver
//
//  Created by ANA on 10/6/21.
//
import UIKit
import Firebase

class ForgotController: UIViewController{
    
    /*Variable Outlet*/
    @IBOutlet var viewContent: UIView!
    @IBOutlet var anchorContentCenterY: NSLayoutConstraint!
    @IBOutlet var emailField: UITextField!
    @IBOutlet var emailErrorLabel: UILabel!
    
    /*Gesture to close keyboard*/
    
    @IBAction func tapToCloseKeyboard(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    /*Method that starts the Controller*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* All Label are Hidden */
        emailErrorLabel.isHidden = true
        
        /* Target Fields */
        emailField.addTarget(self, action: #selector(self.emailDidChange(_:)), for: UIControl.Event.editingChanged)
    }
    
    /*Elector Methods*/
    @objc func emailDidChange(_ textField: UITextField) {
            if(textField.text!.isValidEmail()){
                emailErrorLabel.isHidden = true
            } else{
                emailErrorLabel.isHidden = false
            }
       }
    
    /*Keyboard Methods*/
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       self.registerKeyboardEvents()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       self.unregisterKeyboardEvents()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    /* Navegar a la pantalla Login Controller*/
    
    @IBAction func didTapResetPassword(sender: UIButton){
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginController") else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /*Navigate to the previous screen*/
    
    @IBAction func didTapBackButton(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    
    /*Forgot Password*/
    @IBAction func didTapForgotPasswordButton(_ sender: Any) {
        
        Auth.auth().sendPasswordReset(withEmail: emailField.text!) { (error) in
            if error == nil{
                print("SEND....")
                let alertController = UIAlertController(title: "Forgot Password", message: "Email message was sent to you at" + self.emailField.text!, preferredStyle: .alert)
                
                let closeAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(closeAction)
                self.present(alertController, animated: true, completion: nil)
                                
            } else {
                print("FAILED - \(error!.localizedDescription)")
                let alertController = UIAlertController(title: "An error occured", message: "Oops, something went wrong!", preferredStyle: .alert)
                
                let closeAction = UIAlertAction(title: "Close", style: .cancel, handler: nil)
                alertController.addAction(closeAction)
                self.present(alertController, animated: true, completion: nil)
            }
            
        }
    }
}

/*Keyboard Events*/

extension ForgotController{
    
    func registerKeyboardEvents(){
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillShow(_:)),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
        
    }
    
    func unregisterKeyboardEvents(){
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification){
        
        let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect ?? .zero
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        let finalPosYContent = self.viewContent.frame.origin.y + self.viewContent.frame.height
        
        if keyboardFrame.origin.y < finalPosYContent {
            
            UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut], animations: {
                self.anchorContentCenterY.constant = keyboardFrame.origin.y - finalPosYContent
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    @objc private func keyboardWillHide(_ notification: Notification){
        
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        UIView.animate(withDuration: animationDuration) {
            self.anchorContentCenterY.constant = 0
            self.view.layoutIfNeeded()
        }
    }
    
}



