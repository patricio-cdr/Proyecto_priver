//
//  CreateAccountController.swift
//  priver
//
//  Created by ANA on 10/8/21.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseStorage

class CreateAccountController: UIViewController {
    
    let userType = "conductor"
    
    /*Variable Outlet*/
    
    @IBOutlet var signUpButton: UIButton!
    @IBOutlet var anchorContentCenterY: NSLayoutConstraint!
    @IBOutlet var viewContent: UIView!
    
    @IBOutlet var imgProfilePicture: UIImageView!
    
    /* TextField*/
    @IBOutlet var nameField: UITextField!
    @IBOutlet var lastNameField: UITextField!
    @IBOutlet var emailField: UITextField!
    @IBOutlet var phoneField: UITextField!
    @IBOutlet var passwordField: UITextField!
    
    /*ErrorLabel*/
    @IBOutlet var nameErrorLabel: UILabel!
    @IBOutlet var lastNameErrorLabel: UILabel!
    @IBOutlet var emailErrorLabel: UILabel!
    @IBOutlet var phoneErrorLabel: UILabel!
    @IBOutlet var passwordErrorLabel: UILabel!
    
    /*Method to close Keyboard*/
    @IBAction func tapToCloseKeyboard(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    /*Created User*/
    @IBAction func didTapSignUpButton(_ sender: Any){
        guard let name = nameField.text, let lastname = lastNameField.text, let email = emailField.text,
              let phone = phoneField.text, let password = passwordField.text
        else {
            return
            
        }
        
        Auth.auth().createUser(withEmail: email, password: password){
            user, error in
            if error == nil && user != nil
                {
                print("User created")
                let uid = (Auth.auth().currentUser?.uid)!
                let ref = Database.database().reference(withPath: "drivers").child(uid)
                ref.setValue(["name": name, "LastName": lastname, "Phone": phone, "Type": self.userType])
                
                guard let image = self.imgProfilePicture.image, let data = image.pngData() else{
                    return
                }
                
                let fileName = "\(uid)_profile_picture.png"
                
                self.uploadProfilePicture(with: data, fileName: fileName, completion: { result in
                    switch result {
                    case .success(let downloadUrl):
                        UserDefaults.standard.set(downloadUrl, forKey: "profile:picture_url")
                        print(downloadUrl)
                    case .failure(let error): print("storage manager error: \(error)")
                    }
                })
                
                guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "RequestController") else{
                    return
                }
                self.navigationController?.pushViewController(vc, animated: true)
                
            } else {
                print("Error creating user: \(error!.localizedDescription)")
                let alertController = UIAlertController(title: "An error occured", message: "Oops, something went wrong!", preferredStyle: .alert)
                
                let closeAction = UIAlertAction(title: "Close", style: .cancel, handler: nil)
                alertController.addAction(closeAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
        
      
        
        
        
        
    }
    
    /*Method that starts the Controller*/

    override func viewDidLoad() {
       super.viewDidLoad()
        
        
        imgProfilePicture.layer.masksToBounds = true
        imgProfilePicture.layer.borderWidth = 2
        imgProfilePicture.layer.borderColor = UIColor.lightGray.cgColor
        imgProfilePicture.layer.cornerRadius = 10
                
        /* All Label are Hidden */
        nameErrorLabel.isHidden = true
        lastNameErrorLabel.isHidden = true
        emailErrorLabel.isHidden = true
        phoneErrorLabel.isHidden = true
        passwordErrorLabel.isHidden = true
        
        /* Target Fields */
        nameField.addTarget(self, action: #selector(self.nameDidChange(_:)), for: UIControl.Event.editingChanged)
        
        lastNameField.addTarget(self, action: #selector(self.lastNameDidChange(_:)), for: UIControl.Event.editingChanged)
        
        emailField.addTarget(self, action: #selector(self.emailDidChange(_:)), for: UIControl.Event.editingChanged)
        
        phoneField.addTarget(self, action: #selector(self.phoneDidChange(_:)), for: UIControl.Event.editingChanged)
        
        passwordField.addTarget(self, action: #selector(self.passwordDidChange(_:)), for: UIControl.Event.editingChanged)
        
        /*Selected my profile picture */
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapChangeProfilePic))
        
        imgProfilePicture.addGestureRecognizer(gesture)
        imgProfilePicture.isUserInteractionEnabled = true
    }
    
    /* Elector Methods*/
    
        /*Func to change profile pic*/
    @objc func didTapChangeProfilePic(){
        presentPhotoActionSheet()
    }
    
    @objc func nameDidChange(_ textField: UITextField) {
           if textField.text!.isEmpty || textField.text!.trimmingCharacters(in: .whitespaces).isEmpty {
            nameErrorLabel.isHidden = false
           } else {
            nameErrorLabel.isHidden = true
           }
       }
    
    @objc func lastNameDidChange(_ textField: UITextField) {
           if textField.text!.isEmpty || textField.text!.trimmingCharacters(in: .whitespaces).isEmpty{
            lastNameErrorLabel.isHidden = false
           } else {
            lastNameErrorLabel.isHidden = true
           }
       }
    
    @objc func emailDidChange(_ textField: UITextField) {
            if(textField.text!.isValidEmail()){
                emailErrorLabel.isHidden = true

            } else{
                emailErrorLabel.isHidden = false
            }
       }
    
    @objc func phoneDidChange(_ textField: UITextField) {
           if textField.text!.isEmpty || textField.text!.trimmingCharacters(in: .whitespaces).isEmpty || textField.text!.count < 9{
            phoneErrorLabel.isHidden = false
           } else {
            phoneErrorLabel.isHidden = true
           }
       }
    
    @objc func passwordDidChange(_ textField: UITextField) {
        if textField.text!.isEmpty || textField.text!.trimmingCharacters(in: .whitespaces).isEmpty || textField.text!.count < 6 {
            passwordErrorLabel.isHidden = false

           } else {
            passwordErrorLabel.isHidden = true
           }
       }
    
    /*Keyboard methods*/
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.registerKeyboardEvents()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.unregisterKeyboardEvents()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    /*Navigate to the previous screen*/
    @IBAction func didTapBackButton(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}

/*Keyboard Events - extension CreateAccountController*/

extension CreateAccountController{
    
   
    
    public typealias UploadPictureCompletion = (Result<String, Error>) -> Void
    
    /// Uploads picture to firebase storage and return completion with url string download
    public func uploadProfilePicture(with data: Data, fileName: String, completion: @escaping UploadPictureCompletion){
        
        let storage = Storage.storage().reference()
        storage.child("images/\(fileName)").putData(data, metadata: nil, completion: { metadata, error in
            guard error == nil else{
                //faile
                print("failed to upload data to firebase for picture")
                completion(.failure(StorageErrors.failedToUpload))
                return
            }
            
            storage.child("images/\(fileName)").downloadURL(completion: {url, error in
                guard let url = url else{
                    print("")
                    completion(.failure(StorageErrors.failedtoGetdownloadUrl))
                    return
                }
                
                let urlString = url.absoluteString
                print("download url returned: \(urlString)")
                completion(.success(urlString))
            })
        })
        
    }
    
    public enum StorageErrors: Error{
        case failedToUpload
        case failedtoGetdownloadUrl
    }
    
    
    
    func registerKeyboardEvents(){
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillShow(_:)),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
        
    }
    
    func unregisterKeyboardEvents(){
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification){
        
        let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect ?? .zero
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        let finalPosYContent = self.viewContent.frame.origin.y + self.viewContent.frame.height
        
        if keyboardFrame.origin.y < finalPosYContent {
            
            UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut], animations: {
                self.anchorContentCenterY.constant = keyboardFrame.origin.y - finalPosYContent
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    @objc private func keyboardWillHide(_ notification: Notification){
        
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        UIView.animate(withDuration: animationDuration) {
            self.anchorContentCenterY.constant = 0
            self.view.layoutIfNeeded()
        }
    }
    
}

/*Extension to validate email*/

extension String {
    func isValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}


extension CreateAccountController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func presentPhotoActionSheet(){
        let actionSheet = UIAlertController(title: "Profile Picture", message: "How would you like to select a picture?", preferredStyle: .actionSheet)
       actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
       
        actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { [weak self] _ in
            
            self?.presentCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Chose Photo", style: .default, handler:  { [weak self] _ in
            
            self?.presentPhotoPicker()
            
        }))
        
        present(actionSheet, animated: true)
        
    }
    
    func presentCamera(){
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
    }
    
    func presentPhotoPicker(){
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        guard let selectedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else {
            return
        }
        self.imgProfilePicture.image = selectedImage
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
