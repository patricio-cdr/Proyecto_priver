//
//  RequestController.swift
//  priver
//
//  Created by ANA on 11/19/21.
//

import UIKit
import Firebase

class RequestController: UIViewController{
    
    /* Navegar a la pantalla anterior*/
    

    @IBAction func didTapBackButton(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
        
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        validateUser()
    }
    
    private func validateUser(){
        if FirebaseAuth.Auth.auth().currentUser == nil {
            let vc = LoginController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            present(nav, animated: false)
        }
    }
    
}





