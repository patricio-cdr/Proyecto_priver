//
//  LoginController.swift
//  priver
//
//  Created by ANA on 10/6/21.
//

import UIKit
import Firebase

class LoginController: UIViewController{
    
    /*Variable Outlet*/
    @IBOutlet var anchorContentCenterY: NSLayoutConstraint!
    @IBOutlet weak var viewContent: UIView!
    
    /* TextField*/
    @IBOutlet var emailField: UITextField!
    @IBOutlet var passwordField: UITextField!

    /*ErrorLabel*/
    
    @IBOutlet var emailErrorLabel: UILabel!
    @IBOutlet var passwordErrorLabel: UILabel!
    
    /*Variable Action*/
    @IBAction func tapToCloseKeyboard(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    /*Method that starts the Controller*/
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* All Label are Hidden */
        emailErrorLabel.isHidden = true
        passwordErrorLabel.isHidden = true
        
        /* Target Fields */
        emailField.addTarget(self, action: #selector(self.emailDidChange(_:)), for: UIControl.Event.editingChanged)
        
        passwordField.addTarget(self, action: #selector(self.passwordDidChange(_:)), for: UIControl.Event.editingChanged)
    }
    
    /*Elector Methods*/
    @objc func emailDidChange(_ textField: UITextField) {
            if(textField.text!.isValidEmail()){
                emailErrorLabel.isHidden = true
            } else{
                emailErrorLabel.isHidden = false
            }
       }
    
    @objc func passwordDidChange(_ textField: UITextField) {
        if textField.text!.isEmpty || textField.text!.trimmingCharacters(in: .whitespaces).isEmpty || textField.text!.count < 6 {
            passwordErrorLabel.isHidden = false
           } else {
            passwordErrorLabel.isHidden = true
           }
       }
    
    /*Keyboard Methods*/
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.registerKeyboardEvents()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.unregisterKeyboardEvents()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    /* Navigate to the Forgot Password screen*/
    
    @IBAction func didTapForgotPasswordButton(sender: UIButton){
        
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotController") else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    /*Sign In*/
    @IBAction func didTapSignInButton(_ sender: Any) {
        Auth.auth().signIn(withEmail: emailField.text!, password: passwordField.text!) { (authResult, error) in
            if error != nil{
                let alertController = UIAlertController(title: "Sign in", message: "Could not login. Check your credentials and try again.", preferredStyle: .alert)
                
                let closeAction = UIAlertAction(title: "Try Again", style: .cancel, handler: nil)
                alertController.addAction(closeAction)
                self.present(alertController, animated: true, completion: nil)
            } else{
                guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "RequestController") else{
                    return
                }
                self.navigationController?.pushViewController(vc, animated: true)
            }
           
        }
    }
    
    /*Navigate to the Create Account screen*/
    
    @IBAction func didTapCreateOneButton(sender: UIButton){
        
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountController") else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /*Navigate to the previous screen*/
    
    @IBAction func didTapBackButton(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
}

/*Keyboard Events*/

extension LoginController{
    
    func registerKeyboardEvents(){
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillShow(_:)),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
        
    }
    
    func unregisterKeyboardEvents(){
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification){
        
        let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect ?? .zero
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        let finalPosYContent = self.viewContent.frame.origin.y + self.viewContent.frame.height
        
        if keyboardFrame.origin.y < finalPosYContent {
            
            UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut], animations: {
                self.anchorContentCenterY.constant = keyboardFrame.origin.y - finalPosYContent
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    @objc private func keyboardWillHide(_ notification: Notification){
        
        let animationDuration = notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
        
        UIView.animate(withDuration: animationDuration) {
            self.anchorContentCenterY.constant = 0
            self.view.layoutIfNeeded()
        }
    }
    
}
